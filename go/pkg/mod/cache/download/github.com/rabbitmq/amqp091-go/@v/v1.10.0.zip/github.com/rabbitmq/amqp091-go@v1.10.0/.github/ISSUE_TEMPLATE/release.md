---
name: Release
about: Do not use this template. This template is meant to be used by RabbitMQ maintainers.
title: Release x.y.z
labels: ''
assignees: ''

---

- [ ] Update change log using `github_changelog_generator`
- [ ] Update version in `connection.go` using `change_version.sh`
- [ ] Create a tag
